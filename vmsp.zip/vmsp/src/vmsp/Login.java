/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vmsp;
import java.util.Scanner;
/**
 *
 * @author Wali Vrock
 */
public class Login {
   Scanner sc=new Scanner(System.in);
    String password;
    String ch;
    int id , name;
    public void login()
    {
        if(true)
        {
        System.out.println("\t\t\t\t Login portal");
     try{
         //if(id==match)dtabase
        System.out.println("Enter id: ");
        id = sc.nextInt();
        //else{you dont have id plase sign up} 
        }
        catch(Exception exe)
        {
             System.out.println("Invalid Input!!!!!");
        }
      try{
         //if(id==match)dtabase
     
        //else{you dont have id plase sign up}
        System.out.println("Enter name: ");
        name = sc.nextInt();
        
        }
        catch(Exception exe)
        {
             System.out.println("Invalid Input!!!!!");
        }
     try{
        System.out.println("Enter password");
        password = sc.next();
        }
        catch(Exception exe)
        {
             System.out.println("Invalid number!!!!!");
        }
        
         try{
        System.out.println("Enter D for driver and O for owner");
        ch=sc.next();
        }
        catch(Exception exe)
        {
             System.out.println("Invalid number!!!!!");
        }
         switch( ch)
         {
             case"D": case"d":
             {
             Driver drv=new Driver();
             drv.drive();
             break;
             }
             case"O":
             case"o":
             {
             Owner1 o=new Owner1();
             o.response();
             break;
            }
         }
        }
         else {
     Signup signup = new Signup();
     signup.signup();
        }
        
    }
}
