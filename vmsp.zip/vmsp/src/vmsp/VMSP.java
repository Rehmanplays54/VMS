/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vmsp;

import java.util.Scanner;
import javax.swing.JFrame;

/**
 *
 * @author Wali Vrock
 */
public class VMSP extends JFrame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        Main m= new Main();
        m.setVisible(true);
        Scanner sc=new Scanner(System.in);
        Signup signup=new Signup();
        Login log=new Login();
        String portal;
         System.out.println(" 1 Enter to sign up");
      System.out.println(" 2 Enter to login");
      portal=sc.next();
      
      switch(portal)
      {
          case"1" :
      {
          if(true)
          signup.signup();
          else
          {
              log.login();
          }
      }
          case"2" :
          { 
              if(true)
              log.login();
              else
              {
                  signup.signup();
              }
          }
              
 
      }
  
      
       
        System.out.println("Hello World!");
    }
    }

