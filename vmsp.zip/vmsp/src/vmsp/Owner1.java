/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vmsp;

import java.util.Scanner;

/**
 *
 * @author Wali Vrock
 */
public class Owner1 {
   Scanner sc = new Scanner(System.in);
   int h , n ,count=0 ,min, x=0;
   String ch,name,no,vname,com,vmodel,purpose;
    int num;
    public void response()
    {
           System.out.println("Owner class");
            System.out.println("1 Enter to give vehicle");
            
            
           
            
                System.out.println("invalid input");
            
            System.out.println("2 Enter to return vehicle");
             System.out.println("3 Enter to add vehicle");
            ch=sc.next();
            
          
            
                System.out.println("invalid input");
            
  switch(ch)
            {
                case"1":
                {
                   
                    {
                    System.out.println("Enter vehicle name and vehicle number");
                    name=sc.next();
                    no=sc.next();
                    System.out.println("Enter hour,mintue ");
                    h=sc.nextInt();
                    min=sc.nextInt();
                    }
                 
                    {
                        System.out.println("invalid input");   
                    }
                    for(int j=0;j<h;j++)
        {
                    
                    for(int i=0;i<60;i++)
        {
                     count=count+1;
                    if(min>count)
                    {
                   System.out.println("time taken "+h+min+"  "+count);
                    x=count;
                   
                    }
        }}
        System.out.println("Vehicle has been gotten ");
        }            
                case"2":
                {
                    if(x>count){
                    System.out.println("Entee name and number of vehicle");
                    name=sc.next();no=sc.next();
                        System.out.println("Vecicle return after time ");
                    }
                    
                    else if(x<=count)
                     {
                    System.out.println("Entee name and number of vehicle");
                    name=sc.next();no=sc.next();
                        System.out.println("Vecicle return in time ");
                    }
                    
                }
                case"3":
                {
                   // try{
                    System.out.println("Enter vehicle name: ");
                    vname = sc.next();
                   // }caught(Exception exe)
                    
                    System.out.println("Enter vehile number: ");
                    num = sc.nextInt();
                    System.out.println("Enter model no: ");
                    vmodel =sc.next();
                    System.out.println("Enter company: ");
                    com =sc.next();
                    System.out.println("Enter booking car or renting car ");
                    purpose = sc.next();
                    System.out.println(vname+" has been added");
                    
                }
  }
    }
}

