/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vmsp;

import java.util.Scanner;

/**
 *
 * @author Wali Vrock
 */
public class Driver {
    int h,min;
    String name,no; int count=0;int x=0;
    String ch;
    Scanner sc=new Scanner(System.in);
     Login log=new Login();
        void drive()
        {
            //try
            {
            System.out.println("1 Enter to get vehicle");
            System.out.println("2 Enter to return vehicle");
            ch=sc.next();
            }
            //caught(Exception exe)
            {
                System.out.println("invalid input");
            }
            switch(ch)
            {
                case"1":
                {
                   
                    {
                    System.out.println("Enter vehicle name and vehicle number");
                    name=sc.next();
                    no=sc.next();
                    System.out.println("Enter hour,mintue ");
                    h=sc.nextInt();
                    min=sc.nextInt();
                    }
                 
                    {
                           
                    }
                    for(int j=0;j<h;j++)
        {
                    
                    for(int i=0;i<60;i++)
        {
                     count=count+1;
                    if(min>count)
                    {
                   System.out.println("time taken "+h+min+"  "+count);
                    x=count;
                   
                    }
        }
        System.out.println("Vehicle has been gotten ");
        }
                    
                     }
                case"2":
                {
                    if(x>count){
                    System.out.println("Entee name and number of vehicle");
                    name=sc.next();no=sc.next();
                        System.out.println("Vecicle return after time ");
                    }
                    
                    else if(x<=count)
                     {
                    System.out.println("Entee name and number of vehicle");
                    name=sc.next();no=sc.next();
                        System.out.println("Vecicle return in time ");
                    }
                    
                }
        }
        }
}
