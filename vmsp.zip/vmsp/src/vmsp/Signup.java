/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vmsp;

import java.util.Scanner;

/**
 *
 * @author Wali Vrock
 */
public class Signup {
    Scanner sc = new Scanner(System.in);
    String name,email,password;
    int id;int h,min;int count=0;
  String ch;
  
  
    public void signup()
    {
       // System.out.println(system("cls"));
        System.out.println("\t\t\twelcome to sign up");
        try
        {
          //  if(id==match)
            if(true){
         System.out.println("Enter ID: ");
                 id = sc.nextInt();
}
        }
        //else already exist
        //taken id number
        catch(Exception exe)
        {
            System.out.println("Invalid Input!!!!!");
        }
      System.out.print("\033[H\033[2J");
      System.out.flush();
        try
        {
        System.out.println("Enter name: ");
        name=sc.next();
        }catch(Exception exe)
        {
             System.out.println("Invalid Input!!!!!");
        }
        try{
         System.out.println("Enter Email: ");
        email=sc.next();
        }
        catch(Exception exe)
        {
             System.out.println("Invalid Input!!!!!");
        }
        try{
         System.out.println("Enter password: ");
        password=sc.next();
        }
        catch(Exception exe)
        {
             System.out.println("Invalid Input!!!!!");
        }
        try
        {
         System.out.println("Enter D for driver and O for Owner ");
        ch =sc.next();
        }
        catch(Exception exe)
        {
            System.out.println("Invalid Input");
        }
     Login log=new Login();
     log.login();
    }

    
}

//    public void givevehicle()
//    {
//        String time;
//        String date;
//        String permission;        
//    }
//  public void updateAvailability() {
//    // Code to update the availability status of the driver
//  }

